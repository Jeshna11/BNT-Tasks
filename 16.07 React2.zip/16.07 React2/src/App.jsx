import React from "react";
import { Fragment } from "react";
import "./App.css";
let author = "JESHNA";
let isLogged = true;{/*conditional rendering*/}
function App() {
  return (
    <div className="container">{/*we use class(attribute) in html to avoid those conflicts in jsx it has default className(props)*/}
      <h1 style={{ backgroundColor: "green" }}>React JSX</h1>
      <label htmlFor="user">User Name:</label>{/*we use for in html to avoid those conflicts in console it has default htmlFor*/}
      <input type="text" />
      <h2>JSX JavaScript XML</h2>
      <p>{author}</p>
      {isLogged && <p>Welcome to our website</p>}
      <button style={{ backgroundColor: "blue" }}>Click</button>
    </div>

    // <React.Fragment>
    //   <h1>React JSX</h1>
    // </React.Fragment>

    // <Fragment> {/*does not support any props/attribute like style,id only support keys*/}
    //   <h2>JSX JavaScript XML</h2>
    // </Fragment>

    // <>
    // <h3>Next Chapter</h3>
    // </>
  );
}
export default App;