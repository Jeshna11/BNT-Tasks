import { useState } from "react";
const Counter = () => {
  const [count, setCount] = useState(0);
  function returnState(){
    console.log(100);
    return 100
  }
  const[sample,setSample]=useState(()=>{returnState()});
  function Increase() {
    setCount(count + 1);
  }
  function Decrease() {
    setCount(count - 1);
  }
  return (
    <div>
      <h1>Counter - {count} - {sample}</h1>
      <button onClick={Increase}>Increase</button>
      <button onClick={Decrease}>Decrease</button>
    </div>
  );
};
export default Counter;