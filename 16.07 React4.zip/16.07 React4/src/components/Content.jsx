import Counter from "./Counter";

const Content = () => {
    let user="JESHNA"
    function Click(){
        console.log(user);
    }
    function Me(){
        console.log("Hello");
    }
    function Hi(){
        console.log("Welcome");
        
    }

  return (
    <main>
      <h1>Main content {user}</h1><br />
      <button onClick={Click}>Click Me</button><br />
      <button onClick={Me}>Click Me</button><br />
      <button onClick={Hi}>Click Me</button>
      <Counter />
    </main>
  )
}

export default Content
