function Header(props){
    console.log(props)
    return (
        <header>
            <h1>Todo List</h1>
        </header>
    )
}
export default Header;