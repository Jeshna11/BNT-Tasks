import { Component } from "react";
class Footer extends Component{
    render(){
        console.log(this.props);
        return(
            <footer>
                <h2>Footer</h2>
            </footer>
        )
    }
}  
export default Footer;