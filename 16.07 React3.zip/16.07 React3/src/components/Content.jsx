const Content = () => {
  return (
    <div>
      content
    </div>
  )
}
export default Content;