import './App.css'
import Productlist from './components/Productlist'
function App() {
  return (
    <>
      <Productlist />
    </>
  )
}
export default App