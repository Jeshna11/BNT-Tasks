import { useState } from "react"

const Counter = ({initialCount}) => {
    const[count,setCount]=useState(initialCount)
    function Increase(){
        setCount(count+1)
    }
    function Decrease(){
        setCount(count-1)
    }
  return (
    <div>
      <button onClick={Increase}>+</button>
      <span>{count}</span>
      <button onClick={Decrease}>-</button>
    </div>
  )
}

export default Counter
