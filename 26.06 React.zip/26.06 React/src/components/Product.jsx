import Counter from "./Count"
const Product = ({name,quantity}) => {
  return (
    <div>
      {name}
      <Counter initialCount={quantity}/>
    </div>
  )
}
export default Product