import { useState } from "react"
import Product from "./Product"
const Productlist = () => {
    const[products,setProducts]=useState([
        {name:"Apple",id:1,availability:true,quantity:3},
        {name:"Orange",id:1,availability:true,quantity:3},
        {name:"Grapes",id:1,availability:false,quantity:3},
        {name:"Fig",id:1,availability:true,quantity:3}
    ])
    const[inputValue,setInputValue]=useState("")
    function Add(e){
        if(e.key==="Enter"){
            const newProduct={
                name:e.target.value,
                id:Math.random(),
                availability:true,
                quantity:1
            }
            setProducts([...products,newProduct])
            setInputValue("")
        }
    }
  return (
    <ul>
      <input type="text"
      placeholder="Enter the product"
      value={inputValue}
      onKeyDown={Add}
      />
      {products.map((product)=>{
        return product.availability?(
            <Product 
            key={product.id}
            name={product.name}
            quantity={product.quantity}
            />
        ):null
      })}
    </ul>
  )
}

export default Productlist
