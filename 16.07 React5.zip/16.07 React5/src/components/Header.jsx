const Header = () => {
  return (
    <header>
      <h1>Todo List</h1>
    </header>
  )
}

export default Header
