import styled from "styled-components"
    {/*Variable*/}
    let headingStyle={            
        backgroundColor:"green",
        boxShadow:"10px 10px 5px black"         
    }  

    {/*library for reusability*/}
    let Button=styled.button
    `background-color:blue;
    width:100px;
    height:50px
    `        
    let Button1=styled(Button)
    `background-color:pink`

    let NewButton=styled(Button)
    `
    box-shadow:10px 10px 10px black;
    background-color:red;
    `
const Content = () => {
    let user="ANU"
    function printSomething(e){
        console.log(e.target.innerText);
        console.log("Hello");
        // user="JESH"
        console.log(user);
    }
    function print(event){
        console.log(event.target.innerText);
        user="ABU"
        console.log(user);
    }
    function printSomething1(user){
        console.log("Hello "+user);
    }   
  return (
    // <main>
    //   <h1 style={{backgroundColor:"green"}}>Main Content</h1>  {/*Inline style */}
    // </main>
    
    <main>
        <h1 style={headingStyle}>Main Content - {user}</h1>
        <Button onClick={printSomething}>Click Me</Button>
        <Button1 onClick={(e)=>{print(e)}}>Click</Button1>
        <NewButton onClick={()=>{printSomething1("JESHNA")}}>New</NewButton>
    </main>
  )
}

export default Content